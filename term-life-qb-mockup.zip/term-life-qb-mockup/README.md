
# Term Life Q&B Mockup (EN/DE)

A fully client‑side, clickable prototype of a Term Life quote‑and‑bind journey.  
Works offline, no backend required. Save/Resume uses `localStorage` in your browser.

## Run locally
1. Download and unzip.
2. Open `index.html` in any modern browser (Chrome, Safari, Edge, Firefox).
3. Use the language selector (EN/DE). Progress is saved automatically.

## Publish (static hosting)
- **GitHub Pages**: push the folder to a `gh-pages` branch or enable Pages on `main`.
- **Netlify / Vercel**: drag‑and‑drop the folder; framework = “static site” (no build).
- **S3/CloudFront / Azure Static Web Apps**: upload as static site, default document `index.html`.

## Notes
- Premiums and underwriting are demo‑rules only.
- No personal data leaves your browser.
- You can export the current app state via the footer button.
