
/* Term Life Q&B Mockup — single-file SPA with hash router, EN/DE content */
const $ = (sel, ctx=document) => ctx.querySelector(sel);
const app = $("#app");
const view = $("#view");
const prevBtn = $("#prevBtn");
const nextBtn = $("#nextBtn");
const saveBtn = $("#saveBtn");
const loadBtn = $("#loadBtn");
const downloadBtn = $("#downloadBtn");
const resetBtn = $("#resetBtn");
const langSelect = $("#langSelect");
const progressBar = $("#progressBar");

/* --- i18n strings --- */
const t = {
  en: {
    steps: ["Intro","Quick Quote","Sign Up & Verify","Health","Pay & Bind","Done"],
    next:"Next", prev:"Back", save:"Save", load:"Load", download:"Download JSON", reset:"Reset",
    intro_title:"From first contact to policy delivery",
    intro_sub:"Fast, bilingual journey. Your answers shape the questions.",
    quick_title:"Quick Quote", quick_help:"Just the basics to estimate your price.",
    dob:"Date of Birth", coverage:"Sum insured (€)", term:"Term (years)", smoker:"Smoker?",
    est_premium:"Estimated Premium", per_month:"per month", disclaimer:"Non-binding estimate; final price depends on underwriting.",
    signup_title:"Create Account & Verify Identity", email:"Email", phone:"Phone",
    verify:"Verification method", verify_eid:"eID (preferred)", verify_video:"Video‑ID",
    health_title:"Health Questions", conditions:"Medical conditions", height:"Height (cm)", weight:"Weight (kg)",
    claims:"Previous serious claims", occupation:"Occupation",
    pay_title:"Pay & Bind", pay_sub:"Add payment to bind your policy. (Mock)",
    pay_method:"Payment method", pay_iban:"SEPA IBAN", pay_card:"Card (test)",
    review:"Review", bind:"Bind Policy", success_title:"Policy issued!", success_body:"Your policy PDF is generated (mock) and stored locally.",
    resume:"We auto-save as you go. Use Load to resume later."
  },
  de: {
    steps: ["Intro","Sofortangebot","Registrieren & Identität","Gesundheit","Zahlen & Binden","Fertig"],
    next:"Weiter", prev:"Zurück", save:"Speichern", load:"Laden", download:"JSON exportieren", reset:"Zurücksetzen",
    intro_title:"Von der ersten Anfrage bis zur Policenstellung",
    intro_sub:"Schnelle, zweisprachige Journey. Ihre Antworten steuern die Fragen.",
    quick_title:"Sofortangebot", quick_help:"Nur das Nötigste für eine Preisschätzung.",
    dob:"Geburtsdatum", coverage:"Versicherungssumme (€)", term:"Laufzeit (Jahre)", smoker:"Raucher?",
    est_premium:"Geschätzte Prämie", per_month:"pro Monat", disclaimer:"Unverbindliche Schätzung; endgültiger Preis nach Underwriting.",
    signup_title:"Konto anlegen & Identität prüfen", email:"E‑Mail", phone:"Telefon",
    verify:"Verifizierungsmethode", verify_eid:"eID (bevorzugt)", verify_video:"Video‑ID",
    health_title:"Gesundheitsfragen", conditions:"Krankheiten", height:"Größe (cm)", weight:"Gewicht (kg)",
    claims:"Vorherige schwere Schäden", occupation:"Beruf",
    pay_title:"Bezahlen & Binden", pay_sub:"Zahlungsdaten hinzufügen, um die Police zu binden. (Mock)",
    pay_method:"Zahlungsart", pay_iban:"SEPA‑IBAN", pay_card:"Karte (Test)",
    review:"Prüfen", bind:"Police binden", success_title:"Police ausgestellt!", success_body:"Ihre Policen‑PDF (Mock) wird lokal gespeichert.",
    resume:"Wir speichern automatisch. Über „Laden“ später fortfahren."
  }
};

const state = JSON.parse(localStorage.getItem("qb_state_v1") || "{}");
state.lang = state.lang || "en";
state.step = state.step || 0;
state.form = state.form || {
  dob:"", coverage:100000, term:20, smoker:"no",
  email:"", phone:"", verify:"eid",
  conditions:"none", height:180, weight:75, claims:"no", occupation:"Engineer",
  pay_method:"iban", iban:"DE88 3704 0044 0532 0130 00", card:"4242 4242 4242 4242"
};

// Helpers
function setProgress() {
  const pct = (state.step)/(steps().length-1)*100;
  progressBar.style.width = pct + "%";
}
function steps(){ return t[state.lang].steps; }
function save(){ localStorage.setItem("qb_state_v1", JSON.stringify(state)); }
function money(x){ return new Intl.NumberFormat(undefined, {style:"currency", currency:"EUR", maximumFractionDigits:0}).format(x); }
function ageFromDob(dob){
  if(!dob) return 35;
  const d = new Date(dob), now = new Date();
  let a = now.getFullYear()-d.getFullYear();
  const m = now.getMonth()-d.getMonth();
  if(m<0 || (m===0 && now.getDate()<d.getDate())) a--;
  return Math.max(18, Math.min(70, a));
}
// Very simple premium model: base by age band + term/coverage multipliers + smoker load
function calcPremium(){
  const {dob, coverage, term, smoker} = state.form;
  const age = ageFromDob(dob);
  let base = age<30?8: age<40?12: age<50?20: age<60?35: 60;
  let per100k = base * (term/20) * (coverage/100000);
  if(smoker==="yes") per100k *= 1.45;
  // crude rounding
  return Math.max(5, Math.round(per100k));
}
// Simple rule outcome
function uwOutcome(){
  const {height, weight, smoker, conditions} = state.form;
  const bmi = (weight/((height/100)**2));
  let outcome = "Immediate Approval";
  if(smoker==="yes" || bmi>32 || conditions.toLowerCase().includes("cardio")) outcome = "Refer to Underwriter";
  if(bmi>40) outcome = "Decline (BMI)";
  return {bmi: Math.round(bmi*10)/10, outcome};
}

// Views
function render(){
  document.documentElement.lang = state.lang;
  langSelect.value = state.lang;
  prevBtn.textContent = t[state.lang].prev;
  nextBtn.textContent = state.step === steps().length-1 ? "🔁" : t[state.lang].next;
  saveBtn.textContent = t[state.lang].save;
  loadBtn.textContent = t[state.lang].load;
  downloadBtn.textContent = t[state.lang].download;
  resetBtn.textContent = t[state.lang].reset;
  setProgress();

  const s = state.step;
  view.innerHTML = ""; // clear

  if(s===0){
    const el = document.createElement("section");
    el.className="card";
    el.innerHTML = `
      <h1>${t[state.lang].intro_title}</h1>
      <p class="help">${t[state.lang].intro_sub}</p>
      <div class="kpi">
        <span class="pill">EN / DE</span>
        <span class="pill">Save &amp; Resume</span>
        <span class="pill">Mock Underwriting</span>
        <span class="pill">Local only (no backend)</span>
      </div>
      <hr/>
      <p class="help"> ${t[state.lang].resume} </p>
    `;
    view.appendChild(el);
  }
  if(s===1){
    const el = document.createElement("section");
    el.className="card grid cols-2";
    el.innerHTML = `
      <div>
        <h1>${t[state.lang].quick_title}</h1>
        <p class="help">${t[state.lang].quick_help}</p>
        <label>${t[state.lang].dob}</label>
        <input type="date" id="dob" value="${state.form.dob}"/>
        <div class="input-inline">
          <div>
            <label>${t[state.lang].coverage}</label>
            <input type="number" id="coverage" min="10000" step="10000" value="${state.form.coverage}"/>
          </div>
          <div>
            <label>${t[state.lang].term}</label>
            <select id="term">
              ${[5,10,15,20,25,30].map(y=>`<option ${state.form.term==y?'selected':''}>${y}</option>`).join("")}
            </select>
          </div>
        </div>
        <label>${t[state.lang].smoker}</label>
        <select id="smoker">
          <option value="no" ${state.form.smoker==="no"?"selected":""}>No / Nein</option>
          <option value="yes" ${state.form.smoker==="yes"?"selected":""}>Yes / Ja</option>
        </select>
        <p class="help">${t[state.lang].disclaimer}</p>
      </div>
      <div>
        <div class="alert">
          <div class="row">
            <strong>${t[state.lang].est_premium}</strong>
            <span class="tag">Rule‑based mock</span>
          </div>
          <div style="font-size:2.2rem;margin-top:4px" class="money" id="estPrem">—</div>
          <div class="help">€ / ${t[state.lang].per_month}</div>
          <hr/>
          <div id="uwBox" class="help"></div>
        </div>
      </div>
    `;
    view.appendChild(el);
    const recalc = ()=>{
      // persist
      state.form.dob = $("#dob").value;
      state.form.coverage = +$("#coverage").value;
      state.form.term = +$("#term").value;
      state.form.smoker = $("#smoker").value;
      save();
      $("#estPrem").textContent = money(calcPremium());
      const {bmi, outcome} = uwOutcome();
      $("#uwBox").innerHTML = `BMI: <strong>${bmi}</strong> • Outcome: <strong>${outcome}</strong>`;
    };
    ["dob","coverage","term","smoker"].forEach(id=>$("#"+id).addEventListener("input", recalc));
    recalc();
  }
  if(s===2){
    const el = document.createElement("section");
    el.className="card grid cols-2";
    el.innerHTML = `
      <div>
        <h1>${t[state.lang].signup_title}</h1>
        <label>${t[state.lang].email}</label>
        <input type="email" id="email" value="${state.form.email}" placeholder="name@example.com"/>
        <label>${t[state.lang].phone}</label>
        <input type="tel" id="phone" value="${state.form.phone}" placeholder="+49 170 000000"/>
      </div>
      <div>
        <label>${t[state.lang].verify}</label>
        <select id="verify">
          <option value="eid" ${state.form.verify==="eid"?"selected":""}>${t[state.lang].verify_eid}</option>
          <option value="video" ${state.form.verify==="video"?"selected":""}>${t[state.lang].verify_video}</option>
        </select>
        <div class="alert help">This is a mock. No data is transmitted.</div>
      </div>
    `;
    view.appendChild(el);
    ["email","phone","verify"].forEach(id=>$("#"+id).addEventListener("input", e=>{ state.form[id]=e.target.value; save(); }));
  }
  if(s===3){
    const el = document.createElement("section");
    el.className="card grid cols-2";
    el.innerHTML = `
      <div>
        <h1>${t[state.lang].health_title}</h1>
        <label>${t[state.lang].conditions}</label>
        <input id="conditions" value="${state.form.conditions}"/>
        <div class="input-inline">
          <div><label>${t[state.lang].height}</label><input type="number" id="height" value="${state.form.height}"/></div>
          <div><label>${t[state.lang].weight}</label><input type="number" id="weight" value="${state.form.weight}"/></div>
        </div>
        <label>${t[state.lang].claims}</label>
        <select id="claims">
          <option value="no" ${state.form.claims==="no"?"selected":""}>No / Nein</option>
          <option value="yes" ${state.form.claims==="yes"?"selected":""}>Yes / Ja</option>
        </select>
        <label>${t[state.lang].occupation}</label>
        <input id="occupation" value="${state.form.occupation}"/>
      </div>
      <div class="alert">
        <div id="uwBox2"></div>
      </div>
    `;
    view.appendChild(el);
    const onInput=(id)=> e=>{ state.form[id]= (id==="height"||id==="weight") ? +e.target.value : e.target.value; save(); refreshUW(); };
    ["conditions","height","weight","claims","occupation"].forEach(id=>$("#"+id).addEventListener("input", onInput(id)));
    function refreshUW(){
      const {bmi, outcome} = uwOutcome();
      $("#uwBox2").innerHTML = `<strong>Underwriting:</strong> BMI ${bmi} • ${outcome}<br/><span class="help">Demo rule only.</span>`;
    }
    refreshUW();
  }
  if(s===4){
    const el = document.createElement("section");
    el.className="card grid cols-2";
    el.innerHTML = `
      <div>
        <h1>${t[state.lang].pay_title}</h1>
        <p class="help">${t[state.lang].pay_sub}</p>
        <label>${t[state.lang].pay_method}</label>
        <select id="pay_method">
          <option value="iban" ${state.form.pay_method==="iban"?"selected":""}>${t[state.lang].pay_iban}</option>
          <option value="card" ${state.form.pay_method==="card"?"selected":""}>${t[state.lang].pay_card}</option>
        </select>
        <div id="payFields"></div>
      </div>
      <div>
        <div class="alert">
          <div class="row"><strong>${t[state.lang].review}</strong><span class="tag">Mock</span></div>
          <hr/>
          <div id="reviewBox"></div>
          <hr/>
          <button id="bindBtn" class="btn btn-primary">${t[state.lang].bind}</button>
          <div id="bindMsg" class="help"></div>
        </div>
      </div>
    `;
    view.appendChild(el);
    const drawFields=()=>{
      const pf = $("#payFields");
      pf.innerHTML = state.form.pay_method==="iban"
        ? `<label>${t[state.lang].pay_iban}</label><input id="iban" value="${state.form.iban}"/>`
        : `<label>${t[state.lang].pay_card}</label><input id="card" value="${state.form.card}"/>`;
      const fld = state.form.pay_method==="iban" ? "iban" : "card";
      $("#"+fld).addEventListener("input", e=>{ state.form[fld]=e.target.value; save(); });
    };
    $("#pay_method").addEventListener("input", e=>{ state.form.pay_method=e.target.value; save(); drawFields(); });
    drawFields();
    const review = ()=>{
      $("#reviewBox").innerHTML = `
        Coverage: <strong class="money">€${(+state.form.coverage).toLocaleString()}</strong><br/>
        Term: <strong>${state.form.term}y</strong> • Smoker: <strong>${state.form.smoker}</strong><br/>
        Est. Premium: <strong class="money">${money(calcPremium())}/mo</strong>
      `;
    };
    review();
    $("#bindBtn").addEventListener("click", ()=>{
      $("#bindBtn").disabled = true;
      setTimeout(()=>{
        const policy = { id:"DE-"+Math.random().toString(36).slice(2,8).toUpperCase(),
          issuedAt:new Date().toISOString(), premium: calcPremium(), ...state.form };
        localStorage.setItem("qb_policy", JSON.stringify(policy));
        $("#bindMsg").innerHTML = `<span class="tag">OK</span> Policy ${policy.id} issued (mock). See localStorage.`;
        state.step = 5; save(); render();
      }, 600);
    });
  }
  if(s===5){
    const pol = JSON.parse(localStorage.getItem("qb_policy") || "null");
    const el = document.createElement("section");
    el.className="card";
    el.innerHTML = `
      <h1>✅ ${t[state.lang].success_title}</h1>
      <p>${t[state.lang].success_body}</p>
      <div class="alert"><code>${pol? JSON.stringify(pol,null,2):"No policy"}</code></div>
      <button class="btn btn-secondary" id="startOver">Start Over</button>
    `;
    view.appendChild(el);
    $("#startOver").addEventListener("click", ()=>{ state.step = 0; save(); render(); });
  }

  // buttons
  prevBtn.disabled = s===0;
  nextBtn.disabled = s===5;
}
render();

// Controls
prevBtn.addEventListener("click", ()=>{ if(state.step>0){ state.step--; save(); render(); } });
nextBtn.addEventListener("click", ()=>{ if(state.step<steps().length-1){ state.step++; save(); render(); } });
saveBtn.addEventListener("click", ()=>{ save(); alert("Saved locally."); });
loadBtn.addEventListener("click", ()=>{
  const s = JSON.parse(localStorage.getItem("qb_state_v1") || "null");
  if(s){ Object.assign(state, s); render(); } else alert("Nothing saved yet.");
});
downloadBtn.addEventListener("click", ()=>{
  const blob = new Blob([JSON.stringify(state,null,2)], {type:"application/json"});
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = "qb_state.json"; a.click();
  setTimeout(()=>URL.revokeObjectURL(url), 1500);
});
resetBtn.addEventListener("click", ()=>{
  if(confirm("Clear data and restart?")){ localStorage.removeItem("qb_state_v1"); localStorage.removeItem("qb_policy"); location.reload(); }
});
langSelect.addEventListener("input", (e)=>{ state.lang = e.target.value; save(); render(); });

// Hash router (not strictly needed, but keeps URL sharable per step)
window.addEventListener("hashchange", ()=>{
  const s = parseInt(location.hash.replace("#",""),10);
  if(!isNaN(s)){ state.step = Math.max(0, Math.min(5, s)); save(); render(); }
});
// keep hash in sync
const syncHash = ()=>{ if(parseInt(location.hash.replace("#",""),10)!==state.step){ location.hash = String(state.step); } };
setInterval(syncHash, 300);
